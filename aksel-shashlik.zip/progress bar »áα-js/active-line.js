let pair1 = document.getElementById('progress__line-active-1');
let pair2 = document.getElementById('progress__line-active-2');
let pair3 = document.getElementById('progress__line-active-3');
let pair4 = document.getElementById('progress__line-active-4');
let pair5 = document.getElementById('progress__line-active-5');

let text_pair_1 = document.getElementById('text-pair_1');
let text_pair_2 = document.getElementById('text-pair_2');
let text_pair_3 = document.getElementById('text-pair_3');
let text_pair_4 = document.getElementById('text-pair_4');
let text_pair_5 = document.getElementById('text-pair_5');

let underline_1 = document.getElementById('choose-div-1');
let underline_2 = document.getElementById('choose-div-2');
let underline_3 = document.getElementById('choose-div-3');
let underline_4 = document.getElementById('choose-div-4');
let underline_5 = document.getElementById('choose-div-5');

var active_form = setInterval(function () {
  var today = new Date();
  var hour = today.getHours();
  var minute = today.getMinutes();
  var seconds = today.getSeconds();
  
  let time_code = hour * 3600 + minute * 60 + seconds;

  //* Условия для всех пар
    if(time_code >= 32400 && time_code < 37800){  //TODO период первой пары (9:00 - 10:30)
      check_time_1 = time_code - 32400; 
      progress_1 = 0.0037 * check_time_1;
      let stroka_1 = String(progress_1.toFixed(1) + '%');

      let past_hour = Math.floor((5400 - check_time_1) / 3600);
      let past_minute = Math.floor(((5400 - check_time_1) % 3600) / 60);
      let past_seconds = (5400 - check_time_1) % 60;
      document.getElementById('remaining-hors').innerHTML = past_hour;
      document.getElementById('remaining-minutes').innerHTML = past_minute;
      document.getElementById('remaining-seconds').innerHTML = past_seconds;
      
      pair1.style.width = stroka_1;
      text_pair_1.style.cssText = `
        color: black;
        fontWeight: bolder;
        font-size: 19pt;
      `;
      underline_1.style.cssText = `
        border-bottom: 2px solid #1E90FF;
        border-right: 2px solid #1E90FF;
        border-left: 2px solid #1E90FF;
        border-radius: 0px 0px 24px 24px;
      `;

    }else if(time_code >= 37800 && time_code < 39000){  //TODO Время перемены (10:30 - 10:50)
      pair1.classList.add('bg-secondary');
      text_pair_1.style.cssText = `
        color: none;
        fontWeight: none;
        font-size: none;
      `;
      underline_1.style.cssText = `
        border-bottom: none;
        border-right: none;
        border-left: none;
        border-radius: none;
      `;
      
    }else if(time_code >= 39000 && time_code < 44400){  //TODO период второй пары (10:50 - 12:20)
      pair1.style.width = '20%';
      pair1.classList.add('bg-secondary');
      pair1.classList.remove('progress-bar-animated');
      
      check_time_2 = time_code - 39000;
      progress_2 = 0.0037 * check_time_2;
      let stroka_2 = String(progress_2.toFixed(1) + '%');

      let past_hour = Math.floor((5400 - check_time_2) / 3600);
      let past_minute = Math.floor(((5400 - check_time_2) % 3600) / 60);
      let past_seconds = (5400 - check_time_2) % 60;
      document.getElementById('remaining-hors').innerHTML = past_hour;
      document.getElementById('remaining-minutes').innerHTML = past_minute;
      document.getElementById('remaining-seconds').innerHTML = past_seconds;
      
      pair2.style.width = stroka_2;
      text_pair_2.style.cssText = `
        color: black;
        fontWeight: bolder;
        font-size: 19pt;
      `;
      underline_2.style.cssText = `
        border-bottom: 2px solid #1E90FF;
        border-right: 2px solid #1E90FF;
        border-left: 2px solid #1E90FF;
        border-radius: 0px 0px 24px 24px;
      `;

    }else if(time_code >= 44400 && time_code < 45600){  //TODO Время перемены (12:20 - 12:40)
      pair2.classList.add('bg-secondary');
      text_pair_2.style.cssText = `
        color: none;
        fontWeight: none;
        font-size: none;
      `;
      underline_2.style.cssText = `
        border-bottom: none;
        border-right: none;
        border-left: none;
        border-radius: none;
      `;

    }else if(time_code >= 45600 && time_code < 51000){  //TODO период третьей пары (12:40 - 14:10)
      pair1.style.width = '20%';
      pair1.classList.add('bg-secondary');
      pair1.classList.remove('progress-bar-animated');

      pair2.style.width = '20%';
      pair2.classList.add('bg-secondary');
      pair2.classList.remove('progress-bar-animated');

      check_time_3 = time_code - 45600; 
      progress_3 = 0.0037 * check_time_3;
      let stroka_3 = String(progress_3.toFixed(1) + '%');

      let past_hour = Math.floor((5400 - check_time_3) / 3600);
      let past_minute = Math.floor(((5400 - check_time_3) % 3600) / 60);
      let past_seconds = (5400 - check_time_3) % 60;
      document.getElementById('remaining-hors').innerHTML = past_hour;
      document.getElementById('remaining-minutes').innerHTML = past_minute;
      document.getElementById('remaining-seconds').innerHTML = past_seconds;
      
      pair3.style.width = stroka_3;
      text_pair_3.style.cssText = `
        color: black;
        fontWeight: bolder;
        font-size: 19pt;
      `;
      underline_3.style.cssText = `
        border-bottom: 2px solid #1E90FF;
        border-right: 2px solid #1E90FF;
        border-left: 2px solid #1E90FF;
        border-radius: 0px 0px 24px 24px;
      `;

    }else if(time_code >= 51000 && time_code < 51600){  //TODO Время перемены (14:10 - 14:20)
      pair3.classList.add('bg-secondary');
      text_pair_3.style.cssText = `
        color: none;
        fontWeight: none;
        font-size: none;
      `;
      underline_3.style.cssText = `
        border-bottom: none;
        border-right: none;
        border-left: none;
        border-radius: none;
      `;

    }else if(time_code >= 51600 && time_code < 57000){  //TODO период четвертой пары (14:20 - 15:50)
      pair1.style.width = '20%';
      pair1.classList.add('bg-secondary');
      pair1.classList.remove('progress-bar-animated');

      pair2.style.width = '20%';
      pair2.classList.add('bg-secondary');
      pair2.classList.remove('progress-bar-animated');

      pair3.style.width = '20%';
      pair3.classList.add('bg-secondary');
      pair3.classList.remove('progress-bar-animated');

      check_time_4 = time_code - 51600; 
      progress_4 = 0.0037 * check_time_4;
      let stroka_4 = String(progress_4.toFixed(1) + '%');

      let past_hour = Math.floor((5400 - check_time_4) / 3600);
      let past_minute = Math.floor(((5400 - check_time_4) % 3600) / 60);
      let past_seconds = (5400 - check_time_4) % 60;
      document.getElementById('remaining-hors').innerHTML = past_hour;
      document.getElementById('remaining-minutes').innerHTML = past_minute;
      document.getElementById('remaining-seconds').innerHTML = past_seconds;
      
      pair4.style.width = stroka_4;
      text_pair_4.style.cssText = `
        color: black;
        fontWeight: bolder;
        font-size: 19pt;
      `;
      underline_4.style.cssText = `
        border-bottom: 2px solid #1E90FF;
        border-right: 2px solid #1E90FF;
        border-left: 2px solid #1E90FF;
        border-radius: 0px 0px 24px 24px;
      `;
      
    }else if(time_code >= 57000 && time_code < 57600){  //TODO Время перемены (15:50 - 16:00)
      pair4.classList.add('bg-secondary');
      text_pair_4.style.cssText = `
        color: none;
        fontWeight: none;
        font-size: none;
      `;
      underline_4.style.cssText = `
        border-bottom: none;
        border-right: none;
        border-left: none;
        border-radius: none;
      `;
      
    }else if(time_code >= 57600 && time_code < 63000){  //TODO период пятой пары (16:00 - 17:30)
      pair1.style.width = '20%';
      pair1.classList.add('bg-secondary');
      pair1.classList.remove('progress-bar-animated');

      pair2.style.width = '20%';
      pair2.classList.add('bg-secondary');
      pair2.classList.remove('progress-bar-animated');

      pair3.style.width = '20%';
      pair3.classList.add('bg-secondary');
      pair3.classList.remove('progress-bar-animated');

      pair4.style.width = '20%';
      pair4.classList.add('bg-secondary');
      pair4.classList.remove('progress-bar-animated');

      check_time_5 = time_code - 57600; 
      progress_5 = 0.0037 * check_time_5;
      let stroka_5 = String(progress_5.toFixed(1) + '%');

      let past_hour = Math.floor((5400 - check_time_5) / 3600);
      let past_minute = Math.floor(((5400 - check_time_5) % 3600) / 60);
      let past_seconds = (5400 - check_time_5) % 60;
      document.getElementById('remaining-hors').innerHTML = past_hour;
      document.getElementById('remaining-minutes').innerHTML = past_minute;
      document.getElementById('remaining-seconds').innerHTML = past_seconds;
      
      pair5.style.width = stroka_5;
      text_pair_5.style.cssText = `
        color: black;
        fontWeight: bolder;
        font-size: 19pt;
      `;
      underline_5.style.cssText = `
        border-bottom: 2px solid #1E90FF;
        border-right: 2px solid #1E90FF;
        border-left: 2px solid #1E90FF;
        border-radius: 0px 0px 24px 24px;
      `;
    }else if(time_code >= 63000){ //TODO пары закончились
      pair5.classList.add('bg-secondary');
      text_pair_5.style.cssText = `
        color: none;
        fontWeight: none;
        font-size: none;
      `;
      underline_5.style.cssText = `
        border-bottom: none;
        border-right: none;
        border-left: none;
        border-radius: none;
      `;
    }
  //* ---------->
}, 1000);